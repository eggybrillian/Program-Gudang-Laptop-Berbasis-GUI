package laptop;

import java.awt.HeadlessException;
import java.sql.Connection;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Rezieq
 */
public class data extends javax.swing.JFrame {

    private void kosong_kolom(){
        txtkode.setText(null);
        txtseri.setText(null);
        txtmerk.setText(null);
        txtstok.setText(null);
    }
    
    private void tampil_data(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("No");
        model.addColumn("Kode");
        model.addColumn("Seri");
        model.addColumn("Merk");
        model.addColumn("Stok");
    
        try{
            int no = 1;
            String sql = "SELECT * FROM laptop";
            java.sql.Connection conn = (Connection)konfigdatabase.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet res = stm.executeQuery(sql);
            
            while(res.next()){
                model.addRow(new Object[]{no++, res.getString(1),
                                                res.getString(2),
                                                res.getString(3),
                                                res.getString(4)});
            }
            tabel_gudang.setModel(model);
            
        }catch(SQLException e){
            System.out.println("Eror : " + e.getMessage());
        }
    }
    
    public data() {
        initComponents();
        tampil_data();
        kosong_kolom();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        txtkode = new javax.swing.JTextField();
        txtseri = new javax.swing.JTextField();
        txtmerk = new javax.swing.JTextField();
        txtstok = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel_gudang = new javax.swing.JTable();
        tbReset = new javax.swing.JButton();
        tbTambah = new javax.swing.JButton();
        tbPerbarui = new javax.swing.JButton();
        tbHapus = new javax.swing.JButton();
        tbKeluar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setMaximumSize(new java.awt.Dimension(891, 450));
        jPanel1.setMinimumSize(new java.awt.Dimension(891, 450));
        jPanel1.setPreferredSize(new java.awt.Dimension(891, 450));

        jPanel3.setBackground(new java.awt.Color(204, 255, 255));
        jPanel3.setMinimumSize(new java.awt.Dimension(891, 450));
        jPanel3.setPreferredSize(new java.awt.Dimension(891, 450));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtkode.setBackground(new java.awt.Color(255, 255, 204));
        txtkode.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtkode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtkodeActionPerformed(evt);
            }
        });
        jPanel3.add(txtkode, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 380, -1));

        txtseri.setBackground(new java.awt.Color(255, 255, 204));
        txtseri.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel3.add(txtseri, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 150, 380, -1));

        txtmerk.setBackground(new java.awt.Color(255, 255, 204));
        txtmerk.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtmerk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmerkActionPerformed(evt);
            }
        });
        jPanel3.add(txtmerk, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 210, 380, -1));

        txtstok.setBackground(new java.awt.Color(255, 255, 204));
        txtstok.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel3.add(txtstok, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 260, 380, -1));

        tabel_gudang.setBackground(new java.awt.Color(255, 255, 204));
        tabel_gudang.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tabel_gudang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabel_gudang.setToolTipText("");
        tabel_gudang.setAlignmentX(2.0F);
        tabel_gudang.setAlignmentY(2.0F);
        tabel_gudang.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tabel_gudang.setEditingColumn(1);
        tabel_gudang.setEditingRow(1);
        tabel_gudang.setRequestFocusEnabled(false);
        tabel_gudang.setRowMargin(5);
        tabel_gudang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel_gudangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabel_gudang);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 320, 660, 110));

        tbReset.setBackground(new java.awt.Color(0, 0, 0));
        tbReset.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tbReset.setForeground(new java.awt.Color(255, 255, 255));
        tbReset.setText("Reset");
        tbReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbResetActionPerformed(evt);
            }
        });
        jPanel3.add(tbReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 280, 100, -1));

        tbTambah.setBackground(new java.awt.Color(0, 0, 0));
        tbTambah.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tbTambah.setForeground(new java.awt.Color(255, 255, 255));
        tbTambah.setText("Tambah");
        tbTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbTambahActionPerformed(evt);
            }
        });
        jPanel3.add(tbTambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 80, 100, -1));

        tbPerbarui.setBackground(new java.awt.Color(0, 0, 0));
        tbPerbarui.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tbPerbarui.setForeground(new java.awt.Color(255, 255, 255));
        tbPerbarui.setText("Perbarui");
        tbPerbarui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbPerbaruiActionPerformed(evt);
            }
        });
        jPanel3.add(tbPerbarui, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 130, 100, -1));

        tbHapus.setBackground(new java.awt.Color(0, 0, 0));
        tbHapus.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tbHapus.setForeground(new java.awt.Color(242, 242, 242));
        tbHapus.setText("Hapus");
        tbHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbHapusActionPerformed(evt);
            }
        });
        jPanel3.add(tbHapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 180, 100, -1));

        tbKeluar.setBackground(new java.awt.Color(0, 0, 0));
        tbKeluar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tbKeluar.setForeground(new java.awt.Color(255, 255, 255));
        tbKeluar.setText("Keluar");
        tbKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbKeluarActionPerformed(evt);
            }
        });
        jPanel3.add(tbKeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 230, 100, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/GUDANG LAPTOP SULTAN.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1030, 450));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 850, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(172, 172, 172))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 854, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tbKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbKeluarActionPerformed
        System.exit(0);
    }//GEN-LAST:event_tbKeluarActionPerformed

    private void tbHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbHapusActionPerformed
        try{
            String sql = "DELETE FROM laptop WHERE kode='"+txtkode.getText()+"'";
            java.sql.Connection conn = (Connection)konfigdatabase.configDB();
            java.sql.PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data laptop berhasil dihapus");
        }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampil_data();
        kosong_kolom();
    }//GEN-LAST:event_tbHapusActionPerformed

    private void tbPerbaruiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbPerbaruiActionPerformed
        try{
            String sql = "UPDATE laptop SET kode='"+txtkode.getText()+"',seri='"
                                                         +txtseri.getText()+"',merk='"
                                                         +txtmerk.getText()+"',stok='"
                                                         +txtstok.getText()+"' WHERE kode='"+txtkode.getText()+"'";
            java.sql.Connection conn = (Connection)konfigdatabase.configDB();
            java.sql.PreparedStatement pstm = conn.prepareStatement(sql);
//            sql = String.format(sql, no, nama, partai, kabinet, periode);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data laptop berhasil diperbarui");
            kosong_kolom();
        }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampil_data();
//        kosong_kolom();
    }//GEN-LAST:event_tbPerbaruiActionPerformed

    private void tbTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbTambahActionPerformed
        try{
            String sql = "INSERT INTO laptop VALUES ('"+txtkode.getText()+"','"
                                                           +txtseri.getText()+"','"
                                                           +txtmerk.getText()+"','"
                                                           +txtstok.getText()+"',1)";
            java.sql.Connection conn = (Connection)konfigdatabase.configDB();
            java.sql.PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data laptop berhasil disimpan");
        }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        tampil_data();
        kosong_kolom();
    }//GEN-LAST:event_tbTambahActionPerformed

    private void tbResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbResetActionPerformed
        kosong_kolom();
    }//GEN-LAST:event_tbResetActionPerformed

    private void tabel_gudangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabel_gudangMouseClicked
        int baris = tabel_gudang.rowAtPoint(evt.getPoint());
        String kode = tabel_gudang.getValueAt(baris, 1).toString();
        txtkode.setText(kode);

        String seri = tabel_gudang.getValueAt(baris, 2).toString();
        txtseri.setText(seri);

        String merk = tabel_gudang.getValueAt(baris, 3).toString();
        txtmerk.setText(merk);

        String stok = tabel_gudang.getValueAt(baris, 4).toString();
        txtstok.setText(stok); 
    }//GEN-LAST:event_tabel_gudangMouseClicked

    private void txtkodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtkodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtkodeActionPerformed

    private void txtmerkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmerkActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtmerkActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(data.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(data.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(data.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(data.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new data().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabel_gudang;
    private javax.swing.JButton tbHapus;
    private javax.swing.JButton tbKeluar;
    private javax.swing.JButton tbPerbarui;
    private javax.swing.JButton tbReset;
    private javax.swing.JButton tbTambah;
    private javax.swing.JTextField txtkode;
    private javax.swing.JTextField txtmerk;
    private javax.swing.JTextField txtseri;
    private javax.swing.JTextField txtstok;
    // End of variables declaration//GEN-END:variables
}
